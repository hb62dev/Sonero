# -*- coding: utf-8 -*-
"""
Diagnostic script for the recognition pipeline.
Run with: venv\Scripts\python debug_recognition.py
"""
import asyncio
import sys
import os
import numpy as np
from pathlib import Path

# Force UTF-8 output on Windows
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")


# ── 1. List audio devices ────────────────────────────────────────────────────

def list_audio_devices():
    import sounddevice as sd
    print("\n[DEVICES] Audio input devices available:")
    devices = sd.query_devices()
    for i, d in enumerate(devices):
        if d["max_input_channels"] > 0:
            marker = " <-- DEFAULT INPUT" if i == sd.default.device[0] else ""
            print(f"  [{i:2d}] {d['name']}{marker}")
    print()


# ── 2. Test microphone ───────────────────────────────────────────────────────

def test_microphone(duration: int = 10) -> Path:
    import sounddevice as sd
    import soundfile as sf

    print(f"[MIC] Recording {duration} seconds... Play music near the mic NOW!\n")

    sample_rate = 44100
    recording = sd.rec(
        int(duration * sample_rate),
        samplerate=sample_rate,
        channels=1,
        dtype="float32",
    )
    sd.wait()
    print("[MIC] Recording finished.")

    rms  = float(np.sqrt(np.mean(recording**2)))
    peak = float(np.max(np.abs(recording)))

    print(f"[MIC] RMS level : {rms:.6f}  (need > 0.001 for audio)")
    print(f"[MIC] Peak level: {peak:.6f}  (need > 0.01  for clear audio)")

    if rms < 0.0001:
        print("[MIC] WARNING: SILENCE detected — mic may not be capturing audio.")
        print("       Check Windows sound settings and default recording device.")
    else:
        print("[MIC] OK: Audio captured successfully.")

    out = Path("debug_recording.wav")
    sf.write(str(out), recording, sample_rate)
    print(f"[MIC] Saved to: {out.absolute()}")
    return out


# ── 3. Test Shazam recognition ───────────────────────────────────────────────

async def test_recognition(audio_path: Path):
    from shazamio import Shazam

    print(f"\n[SHAZAM] Sending '{audio_path}' to Shazam API...")
    shazam = Shazam()

    try:
        data = await shazam.recognize(str(audio_path))
        if "track" in data:
            t = data["track"]
            print(f"[SHAZAM] RECOGNIZED: {t.get('subtitle')} - {t.get('title')}")
        else:
            print("[SHAZAM] FAILED: No song recognized.")
            print(f"[SHAZAM] Response keys: {list(data.keys())}")
    except Exception as e:
        print(f"[SHAZAM] ERROR: {e}")


# ── Main ─────────────────────────────────────────────────────────────────────

async def main():
    print("=" * 60)
    print("  Shazam API - Recognition Pipeline Diagnostic")
    print("=" * 60)

    list_audio_devices()

    duration = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    audio_path = test_microphone(duration)
    await test_recognition(audio_path)

    print("\n[DONE] Diagnostic complete.")
    print("  Low RMS  --> mic not capturing audio (check Windows settings)")
    print("  No match --> increase volume or duration, or try again")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
