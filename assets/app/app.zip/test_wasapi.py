"""Test WASAPI loopback recording with pyaudiowpatch."""
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import numpy as np
import soundfile as sf
import pyaudiowpatch as pyaudio

p = pyaudio.PyAudio()

print("=== All loopback devices ===")
for i in range(p.get_device_count()):
    dev = p.get_device_info_by_index(i)
    if dev.get("isLoopbackDevice", False):
        print(f"  [{i}] {dev['name']}  sr={int(dev['defaultSampleRate'])}  ch={dev['maxInputChannels']}")

print("\n=== Default output device ===")
wasapi_info = p.get_host_api_info_by_type(pyaudio.paWASAPI)
default_out_idx = wasapi_info["defaultOutputDevice"]
default_out = p.get_device_info_by_index(default_out_idx)
print(f"  [{default_out_idx}] {default_out['name']}")

# Find matching loopback
loopback = None
for i in range(p.get_device_count()):
    dev = p.get_device_info_by_index(i)
    if dev.get("isLoopbackDevice", False) and default_out["name"] in dev["name"]:
        loopback = dev
        break

if not loopback:
    for i in range(p.get_device_count()):
        dev = p.get_device_info_by_index(i)
        if dev.get("isLoopbackDevice", False):
            loopback = dev
            break

if not loopback:
    print("ERROR: No loopback device found!")
    p.terminate()
    sys.exit(1)

print(f"\nUsing loopback: [{loopback['index']}] {loopback['name']}")
sr       = int(loopback["defaultSampleRate"])
channels = min(int(loopback["maxInputChannels"]), 2)
duration = 5
frames_needed = sr * duration
chunk    = 1024
frames   = []

print(f"Recording {duration}s at {sr}Hz ch={channels} ... PLAY AUDIO NOW!")

stream = p.open(
    format=pyaudio.paFloat32,
    channels=channels,
    rate=sr,
    input=True,
    input_device_index=int(loopback["index"]),
    frames_per_buffer=chunk,
)

collected = 0
while collected < frames_needed:
    data = stream.read(min(chunk, frames_needed - collected), exception_on_overflow=False)
    frames.append(np.frombuffer(data, dtype=np.float32).copy())
    collected += chunk

stream.stop_stream()
stream.close()
p.terminate()

audio = np.concatenate(frames)
if channels > 1:
    audio = audio.reshape(-1, channels).mean(axis=1)

rms = float(np.sqrt(np.mean(audio**2)))
print(f"\nRMS: {rms:.6f}  ({'AUDIO OK!' if rms > 0.001 else 'WARNING: silence'})")

sf.write("test_loopback.wav", audio, sr)
print("Saved: test_loopback.wav")
