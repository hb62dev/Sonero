@echo off
echo Installing PyInstaller and Windows dependencies...
pip install pyinstaller
pip install -r requirements.txt
pip install -r requirements-win.txt

echo.
echo Building executable...
python -m PyInstaller --name "sonero-api" --onefile main.py

echo.
echo Done! The executable is located in the dist\ folder.
pause
