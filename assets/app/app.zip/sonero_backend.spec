# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules

hiddenimports = ['uvicorn.logging', 'uvicorn.loops', 'uvicorn.loops.auto', 'uvicorn.protocols', 'uvicorn.protocols.http', 'uvicorn.protocols.http.auto', 'uvicorn.protocols.websockets', 'uvicorn.protocols.websockets.auto', 'uvicorn.lifespan', 'uvicorn.lifespan.on', 'uvicorn.lifespan.off', 'pydantic', 'pydantic_core', 'pydantic_settings', 'sqlalchemy', 'sqlalchemy.dialects.sqlite', 'aiofiles', 'sounddevice', 'soundfile', 'numpy', 'mutagen', 'PIL', 'httpx', 'yt_dlp']
hiddenimports += collect_submodules('routers')
hiddenimports += collect_submodules('schemas')
hiddenimports += collect_submodules('services')


a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[('routers', 'routers'), ('schemas', 'schemas'), ('services', 'services'), ('config.py', '.'), ('database.py', '.'), ('init_db.py', '.'), ('models.py', '.'), ('.env', '.')],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='sonero_backend',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='sonero_backend',
)
