"""Quick end-to-end test: record -> shazam recognize."""
import asyncio
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

async def main():
    from services.recorder import record_audio
    from services.recognizer import recognize
    import soundfile as sf
    import numpy as np

    print("Recording 10s... PLAY MUSIC NOW!")
    path = await record_audio(10)

    data, sr = sf.read(str(path))
    rms = float(np.sqrt(np.mean(data**2)))
    print(f"RMS: {rms:.5f} ({'OK' if rms > 0.001 else 'WARNING: low signal'})")

    print("Sending to Shazam...")
    track = await recognize(path)

    if track:
        print(f"RECOGNIZED: {track.artist} - {track.title}")
        print(f"Album: {track.album}  |  Genre: {track.genre}  |  Year: {track.year}")
    else:
        print("Not recognized. Try with louder audio or longer duration.")

asyncio.run(main())
